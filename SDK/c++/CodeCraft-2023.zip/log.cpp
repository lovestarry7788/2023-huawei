#include "log.h"

std::ofstream Log::ofs("main.log");